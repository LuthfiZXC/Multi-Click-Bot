#This Script Was Created By Luthfi ZXC
#Subscribe Youtube Channel Luthfi ZXC to Support Us
#Please don't sell this script
#This Script is Open Source
#Please don't claim this script is yours

import requests
import re
import sys
import os
import asyncio

from time import sleep
from telethon import TelegramClient, events
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest, ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest

#Telegram Info
api_id  = 1126719
api_hash = '3389b2abb4a96a82ed0f9efa744faa25'
channel_username = 'AlexCryptoDOGEbot'
ua = {
    'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36'
}

#Bot Button and Command
if channel_username == 'AlexCryptoDOGEbot':
    t1, t2, t3, t4, t5 = '🎉', '🌐', '🤖', '📄', '👥'
    fin1, fin2, fin3, fin4 = 'No Channel', 'No bot', 'No Post', 'No Group'

#Checking Input Format
if len (sys.argv) <2:
    print ("Please use format: python main.py +(your phone number in international format)")
    input ('Press any key to exit...')
    exit(1)
phone_number = sys.argv[1]

#Checking Session Folder
if not os.path.exists("session"):
    os.mkdir("session")




client = TelegramClient("session/"+phone_number, api_id, api_hash)
client.start(phone_number)

c = requests.session()
async def main():
    print("Welcome To Multi Scipt")

    await client.send_message(channel_username, t1)

#-----------------------------Checking Task----------------------------#
########################################################################

    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def cek1(event):
        pesan = event.raw_text
        if fin1 in pesan:
            await client.send_message(channel_username, t3)

    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def cek2(event):
        pesan = event.raw_text
        if fin2 in pesan:
            await client.send_message(channel_username, t4)

    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def cek3(event):
        pesan = event.raw_text
        if fin3 in pesan:
            await client.send_message(channel_username, t5)

    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def habis(event):
        pesan = event.raw_text
        if fin4 in pesan:
            print('Task sudah habis......')
            exit(1)


#------------------------------MAIN SCRIPT-----------------------------#
########################################################################

#Joining Channel
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def join_channel(event):
        pesan = event.raw_text
        channel_id = event.id
        if 'Join this channel' in pesan:

            #Mode Definition
            global mode
            mode = 'join'

            #Getting URL
            url = event.reply_markup.rows[0].buttons[0].url

            #Joining Channel
            await client(JoinChannelRequest(url))
            sleep(1)

            #Clicking Joined Button
            await client(GetBotCallbackAnswerRequest(
                channel_username,
                channel_id,
                data = event.reply_markup.rows[1].buttons[1].data
            ))

#Visiting URL
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def visit(event):
        pesan = event.raw_text
        if 'Open' in pesan:

            #Mode Definition
            global mode
            mode = 'visit'

            #Getting URL
            url = event.reply_markup.rows[0].buttons[0].url
            print(url)

            #Visiting URL
            c.get(url, headers = ua)

#Start Bot
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def start(event):
        pesan = event.raw_text
        channel_id = event.id
        if 'Start' in pesan:

            #Mode Definition
            global mode
            mode = 'start'

            #click joined button
            await client(GetBotCallbackAnswerRequest(
                channel_username,
                channel_id,
                data=event.reply_markup.rows[1].buttons[1].data
            ))

#Forwarding Message
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def forward(event):
        pesan = event.raw_text
        if 'To complete' in pesan:

            #Mode Definition
            global mode
            mode = 'forward'

            #Getting URL
            url = event.message.entities[1].url

            #Deleting refferal Code (u can delete this part)
            if not 'start' in url :
                username = re.search(r't.me/(.*)',url).group(1)
                print(username)

            if 'start' in url:
                username = re.search(r't.me/(.*?)\?',url).group(1)
                print(username)

            #Sending /start to Target Bot
            await client.send_message(username, '/start')

            #Forwarding Message From Target Bot
            @client.on(events.NewMessage(chats=username, incoming=True))
            async def terus(event):
                pesan = event.raw_text
                channel_id = event.id
                print(pesan)
                sleep(2)

                #Forward Message
                await client.forward_messages(channel_username, channel_id, username)

#Reading Post
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def read(event):
        pesan = event.raw_text
        channel_id = event.id
        if 'Read' in pesan:

            #Mode Definition
            global mode
            mode = 'read'

            #Sleep 10 S
            sleep(10)

            #Clicking Watched Button
            await client(GetBotCallbackAnswerRequest(
                channel_username,
                channel_id,
                data = event.reply_markup.rows[0].buttons[1].data
            ))

#Joining Chat
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def join_chat(event):
        pesan = event.raw_text
        channel_id = event.id
        if 'Start' in pesan:
            print('Joining Chat coming soon....')





########################################################################
    @client.on(events.NewMessage(chats=channel_username, incoming=True))
    async def balance(event):
        pesan = event.raw_text
        if 'You earned:' in pesan:
            print(mode)
            bal = re.search(r'You earned: (.*?) DOGE',pesan).group(1)
            print(f'You earned: {bal} DOGE')

            sleep(3)
            if mode == 'join':
                await client.send_message(channel_username,t1)
            if mode == 'visit':
                await client.send_message(channel_username,t2)
            if mode == 'start':
                await client.send_message(channel_username,t3)
            if mode == 'read':
                await client.send_message(channel_username,t4)



    await client.run_until_disconnected()
asyncio.get_event_loop().run_until_complete(main())




#This Script Was Created By Luthfi ZXC
#Subscribe Youtube Channel Luthfi ZXC to Support Us
#Please don't sell this script
#This Script is Open Source
#Please don't claim this script is yours